package bot_r;

import java.sql.Connection;
import java.sql.SQLException;
import bot_r.UserDao;
import bot_r.DatabaseConnection;
import bot_r.TransactionManager;
import bot_r.User;

public class UserService {
    private UserDao userDao = new UserDao();

    public UserService() {
    }

    public void deleteUserByEmail(String email) throws SQLException {
        Connection connection = DatabaseConnection.getConnection();

        try {
            TransactionManager tm = new TransactionManager(connection);
            tm.beginTransaction();

            try {
                this.userDao.deleteUserByEmail(email);
                tm.commit();
            } catch (SQLException var6) {
                SQLException e = var6;
                tm.rollback();
                throw e;
            }
        } catch (Throwable var7) {
            if (connection != null) {
                try {
                    connection.close();
                } catch (Throwable var5) {
                    var7.addSuppressed(var5);
                }
            }

            throw var7;
        }

        if (connection != null) {
            connection.close();
        }

    }

    public void createUser(User user) throws SQLException {
        Connection connection = DatabaseConnection.getConnection();

        try {
            TransactionManager tm = new TransactionManager(connection);
            tm.beginTransaction();

            try {
                this.userDao.insertUser(user);
                tm.commit();
            } catch (SQLException var6) {
                SQLException e = var6;
                tm.rollback();
                throw e;
            }
        } catch (Throwable var7) {
            if (connection != null) {
                try {
                    connection.close();
                } catch (Throwable var5) {
                    var7.addSuppressed(var5);
                }
            }

            throw var7;
        }

        if (connection != null) {
            connection.close();
        }

    }

    public void updateUser(User user) throws SQLException {
        Connection connection = DatabaseConnection.getConnection();

        try {
            TransactionManager tm = new TransactionManager(connection);
            tm.beginTransaction();

            try {
                this.userDao.updateUser(user);
                tm.commit();
            } catch (SQLException var6) {
                SQLException e = var6;
                tm.rollback();
                throw e;
            }
        } catch (Throwable var7) {
            if (connection != null) {
                try {
                    connection.close();
                } catch (Throwable var5) {
                    var7.addSuppressed(var5);
                }
            }

            throw var7;
        }

        if (connection != null) {
            connection.close();
        }

    }

    public User getUserByTelegramId(long telegramid) throws SQLException {
        return this.userDao.getUserByTelegramId(telegramid);
    }

    public User getUserByEmail(String Email) throws SQLException {
        return this.userDao.getUserByEmail(Email);
    }
}

package bot_r;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.telegram.telegrambots.bots.TelegramLongPollingBot;
import org.telegram.telegrambots.meta.api.methods.send.SendMessage;
import org.telegram.telegrambots.meta.api.objects.Update;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.InlineKeyboardMarkup;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.buttons.InlineKeyboardButton;
import org.telegram.telegrambots.meta.exceptions.TelegramApiException;
import bot_r.User;
import bot_r.UserService;

public class botCuestionario extends TelegramLongPollingBot {
    private final Map<Long, Integer> indicePregunta = new HashMap();
    private final Map<Long, String> seccionActiva = new HashMap();
    private final Map<String, String[]> preguntas = new HashMap();
    private final Map<Long, String> estadoConversacion = new HashMap();
    private User usuarioConectado = null;
    private final UserService userService = new UserService();

    public botCuestionario() {
        this.preguntas.put("SECTION_1", new String[]{"\ud83e\udd26\u200d♂️1.1- Estas aburrido?", "\ud83d\ude02\ud83d\ude02 1.2- Te bañaste hoy?", "\ud83e\udd21\ud83e\udd21 Pregunta 1.3"});
        this.preguntas.put("SECTION_2", new String[]{"Pregunta 2.1", "Pregunta 2.2", "Pregunta 2.3"});
        this.preguntas.put("SECTION_3", new String[]{"Pregunta 3.1", "Pregunta 3.2", "Pregunta 3.3"});
        this.preguntas.put("SECTION_4", new String[]{"Pregunta 4.1", "¿Cuál es tu edad?", "Pregunta 4.3"});
    }

    public String getBotUsername() {
        return "@rita_rg_bot";
    }

    public String getBotToken() {
        return "7241139532:AAHAna06uKEt9wCnlG7M-SonMr0hp-9nVC4";
    }

    public void onUpdateReceived(Update update) {
        String callbackData;
        long chatId;
        if (update.hasMessage() && update.getMessage().hasText()) {
            callbackData = update.getMessage().getText();
            chatId = update.getMessage().getChatId();
            this.handleUserRegistration(update, chatId, callbackData);
        } else if (update.hasCallbackQuery()) {
            callbackData = update.getCallbackQuery().getData();
            chatId = update.getCallbackQuery().getMessage().getChatId();
            this.inicioCuestionario(chatId, callbackData);
        }

    }

    private void handleUserRegistration(Update update, long chatId, String messageText) {
        String userFirstName = update.getMessage().getFrom().getFirstName();
        String userLastName = update.getMessage().getFrom().getLastName();
        String nickName = update.getMessage().getFrom().getUserName();

        try {
            String state = (String)this.estadoConversacion.getOrDefault(chatId, "");
            this.usuarioConectado = this.userService.getUserByTelegramId(chatId);
            Long var10001;
            String var10002;
            if (this.usuarioConectado == null && state.isEmpty()) {
                var10001 = chatId;
                var10002 = this.formatUserInfo(userFirstName, userLastName, nickName);
                this.sendText(var10001, "Hola " + var10002 + ", no tienes un usuario registrado en el sistema. Por favor ingresa tu correo electrónico:");
                this.estadoConversacion.put(chatId, "ESPERANDO_CORREO");
            } else if (state.equals("ESPERANDO_CORREO")) {
                this.processEmailInput(chatId, messageText);
            } else {
                var10001 = chatId;
                var10002 = this.formatUserInfo(userFirstName, userLastName, nickName);
                this.sendText(var10001, "Hola " + var10002 + ", bienvenido al sistema de registro de la UMG. Envía /menu para iniciar el cuestionario.");
            }
        } catch (Exception var9) {
            this.sendText(chatId, "Ocurrió un error al procesar tu mensaje. Por favor intenta de nuevo.");
        }

    }

    private void processEmailInput(long chatId, String email) {
        this.sendText(chatId, "Recibo su Correo: " + email);
        this.estadoConversacion.remove(chatId);

        Exception e;
        try {
            this.usuarioConectado = this.userService.getUserByEmail(email);
        } catch (Exception var6) {
            e = var6;
            System.err.println("Error al obtener el usuario por correo: " + e.getMessage());
            e.printStackTrace();
        }

        if (this.usuarioConectado == null) {
            this.sendText(chatId, "El correo no se encuentra registrado en el sistema, por favor contacte al administrador.");
        } else {
            this.usuarioConectado.setTelegramid(chatId);

            try {
                this.userService.updateUser(this.usuarioConectado);
            } catch (Exception var5) {
                e = var5;
                System.err.println("Error al actualizar el usuario: " + e.getMessage());
                e.printStackTrace();
            }

            this.sendText(chatId, "Usuario actualizado con éxito! Envía /menu para iniciar el cuestionario.");
        }

    }

    private void inicioCuestionario(long chatId, String section) {
        this.seccionActiva.put(chatId, section);
        this.indicePregunta.put(chatId, 0);
        this.enviarPregunta(chatId);
    }

    private void enviarPregunta(long chatId) {
        String seccion = (String)this.seccionActiva.get(chatId);
        int index = (Integer)this.indicePregunta.get(chatId);
        String[] questions = (String[])this.preguntas.get(seccion);
        if (index < questions.length) {
            this.sendText(chatId, questions[index]);
        } else {
            this.sendText(chatId, "¡Has completado el cuestionario!");
            this.seccionActiva.remove(chatId);
            this.indicePregunta.remove(chatId);
        }

    }

    private void manejaCuestionario(long chatId, String response) {
        String seccion = (String)this.seccionActiva.get(chatId);
        int index = (Integer)this.indicePregunta.get(chatId);
        if (seccion.equals("SECTION_4") && index == 1) {
            try {
                int edad = Integer.parseInt(response);
                if (edad < 0 || edad > 120) {
                    this.sendText(chatId, "Por favor ingresa una edad válida (entre 0 y 120 años):");
                    return;
                }
            } catch (NumberFormatException var7) {
                this.sendText(chatId, "Por favor ingresa un número válido para la edad:");
                return;
            }
        }

        this.sendText(chatId, "Tu respuesta fue: " + response);
        this.indicePregunta.put(chatId, index + 1);
        this.enviarPregunta(chatId);
    }

    private void sendMenu(long chatId) {
        SendMessage message = new SendMessage();
        message.setChatId(chatId);
        message.setText("Selecciona una sección:");
        InlineKeyboardMarkup markup = new InlineKeyboardMarkup();
        List<List<InlineKeyboardButton>> rows = new ArrayList();
        rows.add(this.crearFilaBoton("Sección 1", "SECTION_1"));
        rows.add(this.crearFilaBoton("Sección 2", "SECTION_2"));
        rows.add(this.crearFilaBoton("Sección 3", "SECTION_3"));
        rows.add(this.crearFilaBoton("Sección 4", "SECTION_4"));
        markup.setKeyboard(rows);
        message.setReplyMarkup(markup);

        try {
            this.execute(message);
        } catch (TelegramApiException var7) {
            TelegramApiException e = var7;
            e.printStackTrace();
        }

    }

    private List<InlineKeyboardButton> crearFilaBoton(String text, String callbackData) {
        InlineKeyboardButton button = new InlineKeyboardButton();
        button.setText(text);
        button.setCallbackData(callbackData);
        List<InlineKeyboardButton> row = new ArrayList();
        row.add(button);
        return row;
    }

    private String formatUserInfo(String firstName, String lastName, String userName) {
        return firstName + " " + lastName + " (" + userName + ")";
    }

    private void sendText(Long chatId, String text) {
        SendMessage message = SendMessage.builder().chatId(chatId.toString()).text(text).build();

        try {
            this.execute(message);
        } catch (TelegramApiException var5) {
            TelegramApiException e = var5;
            e.printStackTrace();
        }

    }
}

package bot_r;

import java.util.HashMap;
import java.util.Map;
import org.telegram.telegrambots.bots.TelegramLongPollingBot;
import org.telegram.telegrambots.meta.api.methods.send.SendMessage;
import org.telegram.telegrambots.meta.api.objects.Update;
import org.telegram.telegrambots.meta.exceptions.TelegramApiException;
import bot_r.User;
import bot_r.UserService;

public class BotRegistra extends TelegramLongPollingBot {
    private Map<Long, String> estadoConversacion = new HashMap();
    User usuarioConectado = null;
    UserService userService = new UserService();

    public BotRegistra() {
    }

    public String getBotUsername() {
        return "@rita_rg_bot";
    }

    public String getBotToken() {
        return "7241139532:AAHAna06uKEt9wCnlG7M-SonMr0hp-9nVC4";
    }

    public void onUpdateReceived(Update update) {
        String userFirstName = update.getMessage().getFrom().getFirstName();
        String userLastName = update.getMessage().getFrom().getLastName();
        String nickName = update.getMessage().getFrom().getUserName();
        long chat_id = update.getMessage().getChatId();
        String mensaje_Texto = update.getMessage().getText();

        try {
            String state = (String)this.estadoConversacion.getOrDefault(chat_id, "");
            this.usuarioConectado = this.userService.getUserByTelegramId(chat_id);
            Long var10001;
            String var10002;
            if (this.usuarioConectado == null && state.isEmpty()) {
                var10001 = chat_id;
                var10002 = this.formatUserInfo(userFirstName, userLastName, nickName);
                this.sendText(var10001, "Hola " + var10002 + ", no tienes un usuario registrado en el sistema. Por favor ingresa tu correo electrónico:");
                this.estadoConversacion.put(chat_id, "ESPERANDO_CORREO");
                return;
            }

            if (state.equals("ESPERANDO_CORREO")) {
                this.processEmailInput(chat_id, mensaje_Texto);
                return;
            }

            var10001 = chat_id;
            var10002 = this.formatUserInfo(userFirstName, userLastName, nickName);
            this.sendText(var10001, "Hola " + var10002 + ", bienvenido al sistema de registro de la UMG. ¿En qué puedo ayudarte?");
        } catch (Exception var9) {
            this.sendText(chat_id, "Ocurrió un error al procesar tu mensaje. Por favor intenta de nuevo.");
        }

    }

    private String formatUserInfo(String firstName, String lastName, String userName) {
        return firstName + " " + lastName + " (" + userName + ")";
    }

    private String formatUserInfo(long chat_id, String firstName, String lastName, String userName) {
        return "" + chat_id + " " + this.formatUserInfo(firstName, lastName, userName);
    }

    private void processEmailInput(long chat_id, String email) {
        this.sendText(chat_id, "Recibo su Correo: " + email);
        this.estadoConversacion.remove(chat_id);

        Exception e;
        try {
            this.usuarioConectado = this.userService.getUserByEmail(email);
        } catch (Exception var6) {
            e = var6;
            System.err.println("Error al obtener el usuario por correo: " + e.getMessage());
            e.printStackTrace();
        }

        if (this.usuarioConectado == null) {
            this.sendText(chat_id, "El correo no se encuentra registrado en el sistema, por favor contacte al administrador.");
        } else {
            this.usuarioConectado.setTelegramid(chat_id);

            try {
                this.userService.updateUser(this.usuarioConectado);
            } catch (Exception var5) {
                e = var5;
                System.err.println("Error al actualizar el usuario: " + e.getMessage());
                e.printStackTrace();
            }

            this.sendText(chat_id, "Usuario actualizado con éxito!");
        }

    }

    public void sendText(Long who, String what) {
        SendMessage sm = SendMessage.builder().chatId(who.toString()).text(what).build();

        try {
            this.execute(sm);
        } catch (TelegramApiException var5) {
            TelegramApiException e = var5;
            throw new RuntimeException(e);
        }
    }
}

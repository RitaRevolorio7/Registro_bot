package bot_r;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.telegram.telegrambots.bots.TelegramLongPollingBot;
import org.telegram.telegrambots.meta.api.methods.send.SendMessage;
import org.telegram.telegrambots.meta.api.objects.Update;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.InlineKeyboardMarkup;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.buttons.InlineKeyboardButton;
import org.telegram.telegrambots.meta.exceptions.TelegramApiException;

public class botPregunton extends TelegramLongPollingBot {
    private final Map<Long, Integer> indicePregunta = new HashMap();
    private final Map<Long, String> seccionActiva = new HashMap();
    private final Map<String, String[]> preguntas = new HashMap();

    public String getBotUsername() {
        return "@rita_rg_bot";
    }

    public String getBotToken() {
        return "7241139532:AAHAna06uKEt9wCnlG7M-SonMr0hp-9nVC4";
    }

    public botPregunton() {
        this.preguntas.put("SECTION_1", new String[]{"\ud83e\udd26\u200d♂️1.1- Estas aburrido?", "\ud83d\ude02\ud83d\ude02 1.2- Te bañaste hoy?", "\ud83e\udd21\ud83e\udd21 Pregunta 1.3"});
        this.preguntas.put("SECTION_2", new String[]{"Pregunta 2.1", "Pregunta 2.2", "Pregunta 2.3"});
        this.preguntas.put("SECTION_3", new String[]{"Pregunta 3.1", "Pregunta 3.2", "Pregunta 3.3"});
    }

    public void onUpdateReceived(Update actualizacion) {
        String messageText;
        long chatId;
        if (actualizacion.hasMessage() && actualizacion.getMessage().hasText()) {
            messageText = actualizacion.getMessage().getText();
            chatId = actualizacion.getMessage().getChatId();
            if (messageText.equals("/menu")) {
                this.sendMenu(chatId);
            } else if (this.seccionActiva.containsKey(chatId)) {
                this.manejaCuestionario(chatId, messageText);
            }
        } else if (actualizacion.hasCallbackQuery()) {
            messageText = actualizacion.getCallbackQuery().getData();
            chatId = actualizacion.getCallbackQuery().getMessage().getChatId();
            this.inicioCuestionario(chatId, messageText);
        }

    }

    private void sendMenu(long chatId) {
        SendMessage message = new SendMessage();
        message.setChatId(chatId);
        message.setText("Selecciona una sección:");
        InlineKeyboardMarkup markup = new InlineKeyboardMarkup();
        List<List<InlineKeyboardButton>> rows = new ArrayList();
        rows.add(this.crearFilaBoton("Sección 1", "SECTION_1"));
        rows.add(this.crearFilaBoton("Sección 2", "SECTION_2"));
        rows.add(this.crearFilaBoton("Sección 3", "SECTION_3"));
        markup.setKeyboard(rows);
        message.setReplyMarkup(markup);

        try {
            this.execute(message);
        } catch (TelegramApiException var7) {
            TelegramApiException e = var7;
            e.printStackTrace();
        }

    }

    private List<InlineKeyboardButton> crearFilaBoton(String text, String callbackData) {
        InlineKeyboardButton button = new InlineKeyboardButton();
        button.setText(text);
        button.setCallbackData(callbackData);
        List<InlineKeyboardButton> row = new ArrayList();
        row.add(button);
        return row;
    }

    private void inicioCuestionario(long chatId, String section) {
        this.seccionActiva.put(chatId, section);
        this.indicePregunta.put(chatId, 0);
        this.enviarPregunta(chatId);
    }

    private void enviarPregunta(long chatId) {
        String seccion = (String)this.seccionActiva.get(chatId);
        int index = (Integer)this.indicePregunta.get(chatId);
        String[] questions = (String[])this.preguntas.get(seccion);
        if (index < questions.length) {
            this.sendText(chatId, questions[index]);
        } else {
            this.sendText(chatId, "¡Has completado el cuestionario!");
            this.seccionActiva.remove(chatId);
            this.indicePregunta.remove(chatId);
        }

    }

    private void manejaCuestionario(long chatId, String response) {
        String var10000 = (String)this.seccionActiva.get(chatId);
        int index = (Integer)this.indicePregunta.get(chatId);
        this.sendText(chatId, "Tu respuesta fue: " + response);
        this.indicePregunta.put(chatId, index + 1);
        this.enviarPregunta(chatId);
    }

    private void sendText(Long chatId, String text) {
        SendMessage message = SendMessage.builder().chatId(chatId.toString()).text(text).build();

        try {
            this.execute(message);
        } catch (TelegramApiException var5) {
            TelegramApiException e = var5;
            e.printStackTrace();
        }

    }
}

package bot_r;
import java.io.PrintStream;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.telegram.telegrambots.meta.TelegramBotsApi;
import org.telegram.telegrambots.updatesreceivers.DefaultBotSession;
import bot_r.BotRegistra;
import bot_r.botPregunton;
import bot_r.User;
import bot_r.UserService;

public class Main {
    public Main() {
    }

    private static void pruebaInsertaUsuario() {
        UserService userService = new UserService();
        User user = new User();
        user.setCarne("0905-12-12345");
        user.setNombre("Andrea Lopez");
        user.setCorreo("ALopez@gmail.com");
        user.setSeccion("A");
        user.setTelegramid(1234567890L);
        user.setActivo("Y");

        try {
            userService.createUser(user);
            System.out.println("Usuario creado exitosamente!");
        } catch (SQLException var3) {
            SQLException e = var3;
            e.printStackTrace();
            System.err.println("Error al crear el usuario: " + e.getMessage());
        }

    }

    private static void pruebaActualizacionUsuario() {
        UserService servicioUsuario = new UserService();

        try {
            User usuarioObtenido = servicioUsuario.getUserByEmail("ALopez@gmail.com");
            if (usuarioObtenido != null) {
                System.out.println("Usuario obtenido: " + usuarioObtenido.getNombre());
                System.out.println("Correo: " + usuarioObtenido.getCorreo());
                System.out.println("ID: " + usuarioObtenido.getId());
                usuarioObtenido.setCarne("0905-12-12345");
                usuarioObtenido.setNombre("Andrea Ascoli");
                usuarioObtenido.setCorreo("anAscoli@gmail.com");
                usuarioObtenido.setSeccion("A");
                usuarioObtenido.setTelegramid(1234567890L);
                usuarioObtenido.setActivo("Y");
                servicioUsuario.updateUser(usuarioObtenido);
                System.out.println("Usuario actualizado exitosamente!");
            } else {
                System.out.println("No se encontró el usuario con el correo proporcionado.");
            }
        } catch (SQLException var2) {
            SQLException e = var2;
            System.out.println("Error al actualizar el usuario: " + e.getMessage());
        }

    }

    private static void pruebaEliminarUsuario() {
        UserService servicioUsuario = new UserService();

        try {
            servicioUsuario.deleteUserByEmail("anAscoli@gmail.com");
            System.out.println("Usuario eliminado exitosamente!");
        } catch (SQLException var2) {
            SQLException e = var2;
            System.out.println("Error al eliminar el usuario: " + e.getMessage());
        }

    }

    public static void explicacionUsoMap() {
        Map<String, String> phoneBook = new HashMap();
        phoneBook.put("Alice", "123-4567");
        phoneBook.put("Bob", "987-6543");
        phoneBook.put("Charlie", "555-7890");
        String bobPhoneNumber = (String)phoneBook.get("Bob");
        System.out.println("El número de Bob es: " + bobPhoneNumber);
        if (phoneBook.containsKey("Alice")) {
            System.out.println("El número de Alice es: " + (String)phoneBook.get("Alice"));
        }

        System.out.println("\nLista completa de contactos:");
        Iterator var2 = phoneBook.entrySet().iterator();

        PrintStream var10000;
        String var10001;
        Map.Entry entry;
        while(var2.hasNext()) {
            entry = (Map.Entry)var2.next();
            var10000 = System.out;
            var10001 = (String)entry.getKey();
            var10000.println("Nombre: " + var10001 + ", Número: " + (String)entry.getValue());
        }

        phoneBook.remove("Charlie");
        System.out.println("\nDespués de eliminar a Charlie, la lista es:");
        var2 = phoneBook.entrySet().iterator();

        while(var2.hasNext()) {
            entry = (Map.Entry)var2.next();
            var10000 = System.out;
            var10001 = (String)entry.getKey();
            var10000.println("Nombre: " + var10001 + ", Número: " + (String)entry.getValue());
        }

        System.out.println("\nEl número total de contactos es: " + phoneBook.size());
    }

    private static void iniciarbPregunton() {
        try {
            TelegramBotsApi botsApi = new TelegramBotsApi(DefaultBotSession.class);
            botPregunton bot = new botPregunton();
            botsApi.registerBot(bot);
            System.out.println("El Bot está funcionando correctamente.");
        } catch (Exception var2) {
            Exception ex = var2;
            System.err.println("Error al iniciar el bot: " + ex.getMessage());
            ex.printStackTrace();
        }

    }

    public static void main(String[] args) {
        try {
            TelegramBotsApi botsApi = new TelegramBotsApi(DefaultBotSession.class);
            BotRegistra bot = new BotRegistra();
            botsApi.registerBot(bot);
            System.out.println("El Bot está funcionando correctamente.");
        } catch (Exception var3) {
            Exception ex = var3;
            System.out.println("Error al iniciar el bot: " + ex.getMessage());
            ex.printStackTrace();
        }

    }
}
package bot_r;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import bot_r.DatabaseConnection;
import bot_r.User;

public class UserDao {
    public UserDao() {
    }

    public void deleteUserByEmail(String email) throws SQLException {
        String query = "DELETE FROM  tb_usuarios WHERE correo = ?";
        Connection connection = DatabaseConnection.getConnection();

        try {
            PreparedStatement statement = connection.prepareStatement(query);

            try {
                statement.setString(1, email);
                statement.executeUpdate();
            } catch (Throwable var9) {
                if (statement != null) {
                    try {
                        statement.close();
                    } catch (Throwable var8) {
                        var9.addSuppressed(var8);
                    }
                }

                throw var9;
            }

            if (statement != null) {
                statement.close();
            }
        } catch (Throwable var10) {
            if (connection != null) {
                try {
                    connection.close();
                } catch (Throwable var7) {
                    var10.addSuppressed(var7);
                }
            }

            throw var10;
        }

        if (connection != null) {
            connection.close();
        }

    }

    public void updateUser(User user) throws SQLException {
        String query = "UPDATE tb_usuarios SET carne = ?, nombre = ?, correo = ?, seccion = ?, telegramid = ?, activo = ? WHERE idusuario = ?";
        Connection connection = DatabaseConnection.getConnection();

        try {
            PreparedStatement statement = connection.prepareStatement(query);

            try {
                statement.setString(1, user.getCarne());
                statement.setString(2, user.getNombre());
                statement.setString(3, user.getCorreo());
                statement.setString(4, user.getSeccion());
                statement.setLong(5, user.getTelegramid());
                statement.setString(6, user.getActivo());
                statement.setInt(7, user.getId());
                statement.executeUpdate();
            } catch (Throwable var9) {
                if (statement != null) {
                    try {
                        statement.close();
                    } catch (Throwable var8) {
                        var9.addSuppressed(var8);
                    }
                }

                throw var9;
            }

            if (statement != null) {
                statement.close();
            }
        } catch (Throwable var10) {
            if (connection != null) {
                try {
                    connection.close();
                } catch (Throwable var7) {
                    var10.addSuppressed(var7);
                }
            }

            throw var10;
        }

        if (connection != null) {
            connection.close();
        }

    }

    public void insertUser(User user) throws SQLException {
        String query = "INSERT INTO tb_usuarios (carne, nombre, correo, seccion, telegramid, activo) VALUES (?, ?, ?, ?, ?, ?)";
        Connection connection = DatabaseConnection.getConnection();

        try {
            PreparedStatement statement = connection.prepareStatement(query);

            try {
                statement.setString(1, user.getCarne());
                statement.setString(2, user.getNombre());
                statement.setString(3, user.getCorreo());
                statement.setString(4, user.getSeccion());
                statement.setLong(5, user.getTelegramid());
                statement.setString(6, user.getActivo());
                statement.executeUpdate();
            } catch (Throwable var9) {
                if (statement != null) {
                    try {
                        statement.close();
                    } catch (Throwable var8) {
                        var9.addSuppressed(var8);
                    }
                }

                throw var9;
            }

            if (statement != null) {
                statement.close();
            }
        } catch (Throwable var10) {
            if (connection != null) {
                try {
                    connection.close();
                } catch (Throwable var7) {
                    var10.addSuppressed(var7);
                }
            }

            throw var10;
        }

        if (connection != null) {
            connection.close();
        }

    }

    public User getUserByTelegramId(long telegramid) throws SQLException {
        String query = "SELECT * FROM tb_usuarios WHERE telegramid = ?";
        Connection connection = DatabaseConnection.getConnection();

        User var8;
        label69: {
            try {
                label70: {
                    PreparedStatement statement = connection.prepareStatement(query);

                    label71: {
                        try {
                            statement.setLong(1, telegramid);
                            ResultSet resultSet = statement.executeQuery();
                            if (resultSet.next()) {
                                User user = new User();
                                user.setId(resultSet.getInt("idusuario"));
                                user.setCarne(resultSet.getString("carne"));
                                user.setNombre(resultSet.getString("nombre"));
                                user.setCorreo(resultSet.getString("correo"));
                                user.setSeccion(resultSet.getString("seccion"));
                                user.setTelegramid(resultSet.getLong("telegramid"));
                                user.setActivo(resultSet.getString("activo"));
                                var8 = user;
                                break label71;
                            }
                        } catch (Throwable var11) {
                            if (statement != null) {
                                try {
                                    statement.close();
                                } catch (Throwable var10) {
                                    var11.addSuppressed(var10);
                                }
                            }

                            throw var11;
                        }

                        if (statement != null) {
                            statement.close();
                        }
                        break label70;
                    }

                    if (statement != null) {
                        statement.close();
                    }
                    break label69;
                }
            } catch (Throwable var12) {
                if (connection != null) {
                    try {
                        connection.close();
                    } catch (Throwable var9) {
                        var12.addSuppressed(var9);
                    }
                }

                throw var12;
            }

            if (connection != null) {
                connection.close();
            }

            return null;
        }

        if (connection != null) {
            connection.close();
        }

        return var8;
    }

    public User getUserByEmail(String Email) throws SQLException {
        String query = "SELECT * FROM tb_usuarios WHERE correo = ?";
        Connection connection = DatabaseConnection.getConnection();

        User var7;
        label69: {
            try {
                label70: {
                    PreparedStatement statement = connection.prepareStatement(query);

                    label71: {
                        try {
                            statement.setString(1, Email);
                            ResultSet resultSet = statement.executeQuery();
                            if (resultSet.next()) {
                                User user = new User();
                                user.setId(resultSet.getInt("idusuario"));
                                user.setCarne(resultSet.getString("carne"));
                                user.setNombre(resultSet.getString("nombre"));
                                user.setCorreo(resultSet.getString("correo"));
                                user.setSeccion(resultSet.getString("seccion"));
                                user.setTelegramid(resultSet.getLong("telegramid"));
                                user.setActivo(resultSet.getString("activo"));
                                var7 = user;
                                break label71;
                            }
                        } catch (Throwable var10) {
                            if (statement != null) {
                                try {
                                    statement.close();
                                } catch (Throwable var9) {
                                    var10.addSuppressed(var9);
                                }
                            }

                            throw var10;
                        }

                        if (statement != null) {
                            statement.close();
                        }
                        break label70;
                    }

                    if (statement != null) {
                        statement.close();
                    }
                    break label69;
                }
            } catch (Throwable var11) {
                if (connection != null) {
                    try {
                        connection.close();
                    } catch (Throwable var8) {
                        var11.addSuppressed(var8);
                    }
                }

                throw var11;
            }

            if (connection != null) {
                connection.close();
            }

            return null;
        }

        if (connection != null) {
            connection.close();
        }

        return var7;
    }
}

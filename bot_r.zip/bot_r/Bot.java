package bot_r;

import org.telegram.telegrambots.bots.TelegramLongPollingBot;
import org.telegram.telegrambots.meta.api.methods.send.SendMessage;
import org.telegram.telegrambots.meta.api.objects.Update;
import org.telegram.telegrambots.meta.exceptions.TelegramApiException;

public class Bot extends TelegramLongPollingBot {
    public Bot() {
    }

    public String getBotUsername() {
        return "@rita_rg_bot";
    }

    public String getBotToken() {
        return "7241139532:AAHAna06uKEt9wCnlG7M-SonMr0hp-9nVC4\n";
    }

    public void onUpdateReceived(Update update) {
        String nombre = update.getMessage().getFrom().getFirstName();
        String apellido = update.getMessage().getFrom().getLastName();
        String nickName = update.getMessage().getFrom().getUserName();
        if (update.hasMessage() && update.getMessage().hasText()) {
            System.out.println("Hola " + nickName + ". Tu nombre es: " + nombre + " y tu apellido es: " + apellido);
            String message_text = update.getMessage().getText();
            long chat_id = update.getMessage().getChatId();
            if (message_text.equalsIgnoreCase("Hola")) {
                this.sendText(chat_id, "Hola " + nombre + ", Gusto Saludarte");
            } else {
                this.sendText(chat_id, "No entendí tu mensaje, pero ¡hola de todos modos!");
            }
        }

    }

    private void sendText(long chatId, String text) {
        SendMessage message = new SendMessage();
        message.setChatId(chatId);
        message.setText(text);

        try {
            this.execute(message);
        } catch (TelegramApiException var6) {
            TelegramApiException e = var6;
            e.printStackTrace();
        }

    }
}
